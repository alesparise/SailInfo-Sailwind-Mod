﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
//poorly written by pr0skynesis (discord username)

namespace SailInfo
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class SailInfoMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.sailinfo";
        public const string pluginName = "SailInfo";
        public const string pluginVersion = "1.0.3";

        //config file info
        //winches stuff
        public static ConfigEntry<bool> winchesOutConfig;
        public static ConfigEntry<bool> winchesBarConfig;
        public static ConfigEntry<bool> sailEfficiencyConfig;
        //HUD display (all information displayed on the rudder when looking at it)
        //rudder
        public static ConfigEntry<bool> rudderBarConfig;
        //wind absolute
        public static ConfigEntry<bool> windSpeedConfig;    //enables the wind speed display
        //public static ConfigEntry<bool> approximateWindSpeedConfig; //makes the wind display text words like strong/weak instead of a number
        public static ConfigEntry<bool> windDirectionConfig;    //enables absolute wind direction display
        public static ConfigEntry<bool> windDirectionNESWConfig; //makes the wind display show approximate cardinal directions (N, NW, SSW, etc.)
        //wind relative
        public static ConfigEntry<bool> windRelativeConfig; //enable the display of the wind direction relative to the boat (0° to 180° and 0° to -180°)
        public static ConfigEntry<bool> windRelativeColorConfig; //makes the relative wind direction display in colore text (red -> Left, green -> Right)
        //boat heading
        public static ConfigEntry<bool> boatHeadingConfig; //enables boat heading display
        public static ConfigEntry<bool> approximateBoatHeading; //makes the heading display show approximate cardinal directions (N, NW, SSW, etc.)
        //boat speed
        public static ConfigEntry <bool> boatSpeedConfig;   //enables the boat speed display





        public void Awake()
        {
            //Logger.LogInfo("Sail Info is loaded!");

            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(GPButtonRopeWinch), "Update");
            MethodInfo patch = AccessTools.Method(typeof(SailInfoPatches), "Update_Patch");
            MethodInfo original2 = AccessTools.Method(typeof(GPButtonSteeringWheel), "Update");
            MethodInfo patch2 = AccessTools.Method(typeof(SailInfoPatches), "Update2_Patch");
            MethodInfo original3 = AccessTools.Method(typeof(SailConnections), "Awake");
            MethodInfo patch3 = AccessTools.Method(typeof(SailInfoPatches), "Awake_Patch");

            //Create config file in BepInEx\config\
            //winches stuff
            winchesOutConfig = Config.Bind("Winches Display", "winchesOutText", true, "Shows 'X out' when looking at winches. 0 means the winch is fully tightened in, 100 means it's fully released. Set to false to disable.");
            winchesBarConfig = Config.Bind("Winches Display", "winchesBar", true, "Shows a loading bar type of thing when looking at winches. Empty bar means the winch is fully tightened in, 100 means it's fully released. Set to false to disable.");
            sailEfficiencyConfig = Config.Bind("Winches Display", "sailEfficiency", true, "Shows the efficiency of the sail attached to the winch you are looking at. Does not apply to halyard winches. 0% means the sail is not generating any force forward, 100% means it's generating the maximum amount of force forward. Set to false to disable.");
            //HUD display (all information displayed on the rudder when looking at it)
            //rudder
            rudderBarConfig = Config.Bind("Rudder HUD", "rudderBar", true, "Shows a loading bar type of thing indicating how much the rudder is turned either way.  Set to false to disable.");
            //wind absolute
            windSpeedConfig = Config.Bind("Rudder HUD", "windSpeed", true, "Shows the APPARENT wind speed.  Set to false to disable.");
            //approximateWindSpeedConfig = Config.Bind("Rudder HUD", "approximateWindSpeed", false, "Makes the wind display show approximate cardinal directions (N, NW, SSW, etc.)");
            windDirectionConfig = Config.Bind("Rudder HUD", "windDirection", true, "Shows APPARENT wind direction in degree, relative to the world (e.g. 45° means the APPARENT wind comes from the North-West).  Set to false to disable.");
            windDirectionNESWConfig = Config.Bind("Rudder HUD", "windDirectionNESW", true, "Shows the approximate cardinal direction of the APPARENT wind (e.g. wind coming from 45° will be shown as NW instead of it's exact numerical value. Set to false to disable. THIS REQUIRES THE PREVIOUS OPTION (windDirection) TO BE SET TO TRUE!");
            //wind relative
            windRelativeConfig = Config.Bind("Rudder HUD", "windAngleToBoat", true, "Shows the angle (0°-180°) between the APPARENT wind and the boat forward direction. Negative angles mean the wind comes from the left of the boat. Set to false to disable.");
            windRelativeColorConfig = Config.Bind("Rudder HUD", "windAngleToBoatColor", true, "Wind direction relative to boat displayed in green it wind comes from the right, red if wind comes from the left. THIS REQUIRES THE PREVIOUS OPTION (windAngleToBoat) TO BE SET TO TRUE! Set to false to disable.");
            //boat heading
            boatHeadingConfig = Config.Bind("Rudder HUD", "boatHeading", false, "Shows the boat heading in degrees. Set to false to disable.");
            approximateBoatHeading = Config.Bind("Rudder HUD", "approximateBoatHeading", true, "Shows the approximate boat heading in cardinal directions (e.g. N, NW, SSE, etc.). THIS REQUIRES THE PREVIOUS OPTION (boatHeading) TO BE SET TO TRUE! Set to false to disable.");
            //boat speed
            boatSpeedConfig = Config.Bind("Rudder HUD", "boatSpeed", false, "Shows current boat speed in kts. Set to false to disable.");

            harmony.Patch(original, new HarmonyMethod(patch)); //patch applied
            harmony.Patch(original2, new HarmonyMethod(patch2)); //patch applied
            harmony.Patch(original3, new HarmonyMethod(patch3)); //patch applied
        }
    }
    public class SailInfoPatches   //contains the patch
    {
        public static Dictionary<Sail, List<RopeController>> sailRopeControllerMap = new Dictionary<Sail, List<RopeController>>();
        
        [HarmonyPrefix] //patch happens before original
        public static void Update_Patch(ref string ___description, RopeController ___rope, GoPointer ___stickyClickedBy, bool ___isLookedAt)
        {
            if (___isLookedAt || ___stickyClickedBy)
            {   
                 ___description = RopeBar(___rope);
            }
        }
        public static string RopeBar(RopeController rope)
        {   //possibly useful ASCII characters: ████░░░░░░ ████▒▒▒▒ ■□□□□ ▄▄▄... ▀▀    ═══───
            float amount = rope.currentLength;
            int barLength = 300; // Total length of the loading bar
            int filledLength = (int)(amount * barLength); // Calculate the number of filled characters
            string description = "";

            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < barLength; i++)
            {
                if (i < filledLength)
                {
                    bar.Append("█"); // Filled character
                }
                else
                {
                    bar.Append("░"); // Empty character
                }
            }
            float sailOut = Mathf.Round(amount * 100);
            if (rope.name.Contains("reef"))
            {   //do this if it's an halyard winch
                if (SailInfoMain.winchesOutConfig.Value)
                {
                    description = $"<size=70%>{sailOut} out</size>";
                }
                if (SailInfoMain.winchesBarConfig.Value)
                {
                    description += $"\n<size=3%>{bar}</size>";
                }
            }
            else
            {   //do this if it's a sheet winch
                if (SailInfoMain.sailEfficiencyConfig.Value)
                {
                    description = $"<size=70%>Eff: {SailEfficiency(rope)}%</size>";
                }
                if (SailInfoMain.winchesOutConfig.Value)
                {
                    description += $"<size=70%>\n{sailOut} out</size>";
                }
                if (SailInfoMain.winchesBarConfig.Value)
                {
                    description += $"\n<size=3%>{bar}</size>";
                }
                //description = $"<size=70%>Eff: {SailEfficiency(rope)}%\n{sailOut} out</size>\n<size=3%>{bar}</size>";
            }
            return description;
        }
        [HarmonyPrefix] //patch happens before original
        public static void Update2_Patch(ref string ___description, GoPointer ___stickyClickedBy, bool ___isLookedAt, Rudder ___rudder, HingeJoint ___attachedRudder)
        {
            if (___isLookedAt || ___stickyClickedBy)
            {
                ___description = "";
                if(SailInfoMain.windSpeedConfig.Value || SailInfoMain.windDirectionConfig.Value || SailInfoMain.windRelativeConfig.Value)
                {
                    ___description = "Wind: ";
                }
                if (SailInfoMain.windSpeedConfig.Value)
                {
                    ___description += $"{Mathf.Round(WindForce())} kts ";
                }
                if (SailInfoMain.windDirectionConfig.Value)
                {
                    if (SailInfoMain.windDirectionNESWConfig.Value)
                    {
                        ___description += $"{DirectionNESW(Mathf.Round(WindDirection()))} ";
                    }
                    else
                    {
                        ___description += $"{Mathf.Round(WindDirection())}° ";
                    }
                }
                if (SailInfoMain.windRelativeConfig.Value)
                {
                    if (SailInfoMain.windRelativeColorConfig.Value)
                    {
                        float angleToBoat = AngleToBoat();
                        if (angleToBoat > 0f)
                        {   //positive angle means right, so green color.
                            ___description += $"<color=#113905>{Mathf.Round(angleToBoat)}°</color>";
                        }
                        else
                        {
                            ___description += $"<color=#7C0000>{Mathf.Round(angleToBoat)}°</color>";
                        }
                        
                    }
                    else
                    {
                        ___description += $"{Mathf.Round(AngleToBoat())}°";
                    }
                }
                if (SailInfoMain.boatHeadingConfig.Value || SailInfoMain.boatSpeedConfig.Value)
                {
                    ___description += "\n";
                }
                if (SailInfoMain.boatHeadingConfig.Value)
                {
                    if (SailInfoMain.approximateBoatHeading.Value)
                    {
                        ___description += $"HDG: {DirectionNESW(Mathf.Round(BoatHeading()) - 180f)} ";
                    }
                    else
                    {
                        ___description += $"HDG: {Mathf.Round(BoatHeading())}° ";
                    }
                }
                if (SailInfoMain.boatSpeedConfig.Value)
                {
                    ___description += $"SPD: {Mathf.Round(BoatSpeed())} kts";
                }
                if (SailInfoMain.rudderBarConfig.Value)
                {
                    ___description += $"\n{RudderBar(___rudder.currentAngle, ___attachedRudder.limits.max)}";
                }
            }
        }
        public static string RudderBar(float currentAngle, float angleLimit)
        {
            int barLength = 150;
            bool turnedRight = currentAngle <= 0;
            string description;
            string emptySide = "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░";
            int filledLength = (int)(Math.Abs(currentAngle) * barLength / angleLimit);
            int emptyLength = barLength - filledLength;

            StringBuilder barRight = new StringBuilder();
            for (int i = 0; i < barLength; i++)
            {
                if (i < filledLength)
                {
                    barRight.Append("█"); // Filled character
                }
                else
                {
                    barRight.Append("░"); // Empty character
                }
            }
            StringBuilder barLeft = new StringBuilder();
            for (int i = 0; i < barLength; i++)
            {
                if (i < emptyLength)
                {
                    barLeft.Append("░"); // Filled character
                }
                else
                {
                    barLeft.Append("█"); // Empty character
                }
            }
            if(turnedRight)
            {
                description = $"<size=3%>{emptySide}█{barRight}</size>";
            }
            else
            {
                description = $"<size=3%>{barLeft}█{emptySide}</size>";
            }
            return description;
        }
        private static float SailEfficiency(RopeController rope)
        {   // Calculates the efficiency of a sail regulation
            
            //Identifies what sail the controller being looked at is attached to!
            foreach (var sail in sailRopeControllerMap)
            {
                foreach (var ropeController in sail.Value)
                {
                    if (rope == ropeController)
                    {
                        //This is the sail the looked controller controls
                        Sail currentSail = sail.Key;
                        //This is the force created by the sail
                        FieldInfo unamplifiedForceInfo = AccessTools.Field(typeof(Sail), "unamplifiedForwardForce");
                        float unamplifiedForce= (float)unamplifiedForceInfo.GetValue(currentSail);
                        //This is the total force the wind applies to the sail. this is also the maximum force forward the sail can generate on the boat.
                        FieldInfo totalWindForceInfo = AccessTools.Field(typeof(Sail), "totalWindForce");
                        float totalWindForce = (float)totalWindForceInfo.GetValue(currentSail);
                        
                        float efficiency = Mathf.Round(unamplifiedForce / totalWindForce * 100f);
                        //if (unamplifiedForce == 0f)
                        //{   //why is this necessary? It's already a thing...
                        //   efficiency = 0f;
                        //}
                        return efficiency;
                    }
                }
            }
            return 0;
        }
        private static float WindForce()
        {
            return GameState.currentBoat.GetComponentInChildren<Sail>().apparentWind.magnitude;
        }
        private static float WindDirection()
        {   //calculate apparent wind direction in an absolute frame of reference
            Transform currentShip = GameState.currentBoat;
            Sail anySail = currentShip.GetComponentInChildren<Sail>();

            float windDirection = Vector3.SignedAngle(anySail.apparentWind, -Vector3.forward, Vector3.up);
            windDirection = windDirection < 0 ? windDirection + 360f : windDirection;

            return windDirection;
        }
        private static float BoatHeading()
        {   //calculates boat heading in an absolute frame of reference
            Transform currentShip = GameState.currentBoat;
            Vector3 boatDirection = -currentShip.transform.right;

            float boatHeading = Vector3.SignedAngle(boatDirection, -Vector3.forward, Vector3.up);
            boatHeading = boatHeading < 0 ? boatHeading + 360f : boatHeading;

            return boatHeading;
        }
        private static float AngleToBoat()
        {   //calculates angle between boat and apparent wind, 0 to 180°. Positive on the right, negative on the left
            Transform currentShip = GameState.currentBoat;
            Sail anySail = currentShip.GetComponentInChildren<Sail>();
            Vector3 boatDirection = -currentShip.transform.right;
            
            return Vector3.SignedAngle(boatDirection, anySail.apparentWind, Vector3.up);
        }
        private static float BoatSpeed()
        {   //calculates boat speed in kts
            Transform currentShip = GameState.currentBoat;
            float boatSpeed = currentShip.parent.GetComponent<Rigidbody>().velocity.magnitude;

            return boatSpeed * 1.94384f;
        }
        private static string DirectionNESW(float direction)
        {   //takes in an angle 0-360 and returns a string representing it's cardinal direction (eg. N, NNW, NW, etc.)
            
            // Ensure direction is within the range 0-360 degrees
            direction = (direction + 360) % 360;

            // Define the sectors and their corresponding directions
            string[] sectors = { "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW" };

            // Calculate the index of the sector based on the wind direction
            int sectorIndex = (int)((direction + 11.25f) / 22.5f) % 16;

            // Return the corresponding direction
            return sectors[sectorIndex];
        }
        [HarmonyPostfix]
        public static void Awake_Patch(Sail ___sail, RopeController ___angleControllerMid, RopeController ___angleControllerLeft, RopeController ___angleControllerRight)
        {
            //Imho this is the best part of this code.
            //This creates a map that associates each rope controller (that is a sheet controller) to a sail,
            //and saves it into a dictionary. Sail name is the key.

            if (___angleControllerMid != null)
            {
                sailRopeControllerMap[___sail] = new List<RopeController> { ___angleControllerMid };
                //Debug.LogError($"SailInfo: Added {___angleControllerMid.name} to the sail {___sail.name}");
            }
            else if (___angleControllerLeft != null && ___angleControllerRight != null)
            {
                sailRopeControllerMap[___sail] = new List<RopeController> { ___angleControllerLeft, ___angleControllerRight };
                //Debug.LogError($"SailInfo: Added {___angleControllerLeft.name} and {___angleControllerRight.name} to the sail {___sail.name}");
            }
            else
            {
                //Debug.LogError("SailInfo: all ropecontrollers are null!");
            }
        }
    }
}
